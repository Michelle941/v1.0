<?php

?>
<h1><?=$ticket->party->title;?></h1>
Ticket holder <?=$ticket->user->name.' '.$ticket->user->last_name;?>
