<?php
use yii\helpers\Url;
?>

<div class="row">
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header" title="" data-toggle="tooltip" data-original-title="Header tooltip">
                <h3 class="box-title"> </h3>
            </div>
            <div class="box-body">

            </div>
            <div class="box-footer">
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="box box-primary">
            <div class="box-header" title="" data-toggle="tooltip" data-original-title="Header tooltip">
                <h3 class="box-title"> </h3>
            </div>
            <div class="box-body">

            </div>
            <div class="box-footer">
            </div>
        </div>
    </div>
</div>