<?php
echo "Sorry, an error occurred: " . htmlentities($id);
?>