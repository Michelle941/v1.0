<?php
use yii\helpers\Html;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
?>
<div class="popup" style="font-family: 'Questrial', sans-serif;">
    <p>Password change Successful.</p><br>
    <p>You better not forget it again!</p><br>
    <p>Love,</p>
    <p>Michelle & Lexi</p>
</div>
