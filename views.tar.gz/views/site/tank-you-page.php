<?php
echo "Thank you for your purchase! Transaction id: " . htmlentities($id);
?>