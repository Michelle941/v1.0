<?php
use app\models\Statistic;

header("Location: http://ec2-54-213-43-16.us-west-2.compute.amazonaws.com/member/qt" . $model->id);
exit();
?>

